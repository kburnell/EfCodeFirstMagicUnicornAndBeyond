﻿
namespace Demo1.Domain
{
    public class Part
    {

        public int PartKey { get; set; }
        public string Name { get; set; }
    }
}