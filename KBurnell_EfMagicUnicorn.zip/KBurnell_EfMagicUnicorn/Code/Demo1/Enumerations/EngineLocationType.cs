﻿namespace Demo1.Enumerations {

    public enum EngineLocationType {
        Front,
        Mid,
        Rear
    }
}